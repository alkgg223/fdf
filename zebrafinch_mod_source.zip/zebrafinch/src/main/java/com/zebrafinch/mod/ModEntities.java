package com.zebrafinch.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ZebraFinchMod.MODID);

    // Same hitbox as the vanilla parrot (0.5 x 0.9)
    public static final DeferredHolder<EntityType<?>, EntityType<ZebraFinch>> ZEBRA_FINCH =
            ENTITIES.register("zebra_finch", () -> EntityType.Builder.of(ZebraFinch::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.9F)
                    .clientTrackingRange(8)
                    .build("zebra_finch"));
}
