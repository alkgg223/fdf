package com.zebrafinch.mod;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

/**
 * Model is built at 2x resolution (so the texture is sharper) and the renderer scales it by 0.5,
 * giving the same overall size as the vanilla parrot.
 */
public class ZebraFinchModel extends EntityModel<ZebraFinch> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(ZebraFinchMod.MODID, "zebra_finch"), "main");

    private final ModelPart root;
    private final ModelPart body, head, leftLeg, rightLeg, leftWing, rightWing, tail;

    public ZebraFinchModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.tail = body.getChild("tail");
        this.leftWing = body.getChild("left_wing");
        this.rightWing = body.getChild("right_wing");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition pd = mesh.getRoot();

        PartDefinition body = pd.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -4F, -5F, 8F, 8F, 10F),
                PartPose.offsetAndRotation(0F, 15F, 0F, -0.6F, 0F, 0F));
        body.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(0, 42).addBox(-3F, -1F, 0F, 6F, 2F, 10F),
                PartPose.offsetAndRotation(0F, -2F, 5F, 0.3F, 0F, 0F));
        body.addOrReplaceChild("right_wing",
                CubeListBuilder.create().texOffs(0, 56).addBox(-1F, 0F, 0F, 2F, 4F, 11F),
                PartPose.offset(-5F, -3F, -4F));
        body.addOrReplaceChild("left_wing",
                CubeListBuilder.create().texOffs(28, 56).addBox(-1F, 0F, 0F, 2F, 4F, 11F),
                PartPose.offset(5F, -3F, -4F));

        PartDefinition head = pd.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 20).addBox(-3F, -3F, -3F, 6F, 6F, 6F),
                PartPose.offset(0F, 8.5F, -4.5F));
        head.addOrReplaceChild("beak_upper",
                CubeListBuilder.create().texOffs(0, 34).addBox(-1.5F, 0F, -6F, 3F, 2F, 3F), PartPose.ZERO);
        head.addOrReplaceChild("beak_lower",
                CubeListBuilder.create().texOffs(14, 34).addBox(-1F, 2F, -5F, 2F, 1F, 2F), PartPose.ZERO);

        CubeListBuilder leg = CubeListBuilder.create()
                .texOffs(24, 34).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F)
                .texOffs(30, 34).addBox(-1.5F, 4F, -3.5F, 3F, 1F, 4F);
        pd.addOrReplaceChild("left_leg", leg, PartPose.offset(2F, 19F, 1F));
        pd.addOrReplaceChild("right_leg", leg, PartPose.offset(-2F, 19F, 1F));

        return LayerDefinition.create(mesh, 64, 80);
    }

    @Override
    public void setupAnim(ZebraFinch entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        // ageInTicks carries the flap angle (see renderer.getBob)
        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);

        if (entity.isFlying()) {
            float a = 0.15F + ageInTicks * 0.55F;
            this.rightWing.zRot = a;
            this.leftWing.zRot = -a;
            this.body.xRot = -0.35F;
            this.leftLeg.xRot = 0.6F;
            this.rightLeg.xRot = 0.6F;
        } else {
            this.rightWing.zRot = 0.04F;
            this.leftWing.zRot = -0.04F;
            this.body.xRot = -0.6F;
            this.leftLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.0F * limbSwingAmount;
            this.rightLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.0F * limbSwingAmount;
        }
    }


    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
