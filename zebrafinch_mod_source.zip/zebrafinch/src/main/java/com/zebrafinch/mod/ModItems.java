package com.zebrafinch.mod;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ZebraFinchMod.MODID);

    public static final DeferredItem<DeferredSpawnEggItem> SPAWN_EGG = ITEMS.register("zebra_finch_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ZEBRA_FINCH, 0xA39D96, 0xF57C12, new Item.Properties()));
}
